# CLAUDE.md

### 1. 核心设计规则

- **独立实现**：严禁在算法实现中直接调用 common-math、jblas 等第三方 Java 数学库。测试中的对比基准除外。
- **接口/实现分离**：API 返回 `IVector`、`IMatrix` 等接口类型；具体实现类以 `Rere` 前缀命名（如 `RereDoubleMatrix`），表示由 RereMouse 手动实现。**外部调用一律使用 `Linalg` 静态工厂**，禁止 `new RereXXX()`。
- **流式 API**：绝大多数操作返回新实例（不可变模式），支持链式调用。参考 NumPy 与 Sklearn 风格。
- **子门面模式**：`ML`、`Signals`、`TSA`、`Opts` 通过公开的 final 实例字段暴露功能，IDE 输入 `ML.` 后由自动补全引导。子门面结构见第 2 节。
- **惰性缓存**：矩阵分解（`eigen()`、`svd()`、`qr()`、`lu()`、`cholesky()` 等）首次调用时计算并缓存结果，后续调用直接返回缓存。修改矩阵数据后缓存自动失效。

### 2. 九大门面类及子门面结构

| 门面入口 | 包路径 | 子门面（实例字段） | 职责 |
|----------|--------|-------------------|------|
| `Linalg` | `com.yishape.lab.math.linalg` | — | 向量/矩阵/张量/稀疏/复数创建，分解，求解 |
| `DataFrame` | `com.yishape.lab.math.data` | — | CSV 读写，数据切片，矩阵转换 |
| `Stats` | `com.yishape.lab.math.stats` | `.estimator` `.tester` `.anova` | 14 种分布，假设检验，参数估计，ANOVA |
| `ML` | `com.yishape.lab.math.ml` | `.clf` `.reg` `.dr` `.clu` `.dml` `.preproc` | 分类，回归，降维，聚类，度量学习，预处理 |
| `Opts` | `com.yishape.lab.math.optimize` | `.mclp` `.mcqp` | 无约束/在线优化，线性规划，多目标LP/QP |
| `Signals` | `com.yishape.lab.math.signal` | `.gen` `.filt` `.xform` `.analyze` | 信号生成，滤波，变换，频谱分析 |
| `TSA` | `com.yishape.lab.math.timeseries` | `.forecast` `.filter` `.decompose` `.cointegrate` | 时间序列预测，滤波，分解，协整分析 |
| `Plots` | `com.yishape.lab.math.plot` | — | 2D/3D 图表，JavaFX/ECharts/SVG 三后端 |
| `VI` | `com.yishape.lab.math.vecidx` | — | 向量索引：HNSW、LSH、PQ、KD-Tree |

**使用示例**：`ML.clf.randomForest()`、`Signals.gen.sineWave(...)`、`TSA.forecast.arima(...)`、`Opts.mclp.weightedSumMclp(...)`。

### 3. 编码约定

- **包分层**：接口在包根目录，实现在 `impl/` 子包，算法辅助类在 `support/` 子包。新增分解算法时，接口放 `decomposition/`，实现在 `decomposition/impl/`，求解器在 `decomposition/solver/`。
- **命名**：接口以 `I` 开头（`IVector`、`IMatrix`、`IClassifier`），具体实现以 `Rere` 开头（`RereDoubleMatrix`、`RereLBFGS`）。Wrapper 类以 `Wrapper` 结尾（`ClfWrapper`、`GenWrapper`）。
- **测试**：单元测试用 JUnit 5（`org.junit.jupiter`）。性能敏感代码需补充 JMH 基准测试（`org.openjdk.jmh`）。测试中允许使用 `commons-math4-legacy` 做对照组。
- **异常**：矩阵分解失败用 `DecompositionFailedException` 或子类（`SingularMatrixException`、`NonPositiveDefiniteMatrixException`、`NonSymmetricMatrixException`、`NonSquareMatrixException`）。
- **注释**：仅在 WHY 非显而易见时写注释——数值稳定性技巧、收敛条件选择、特定算法的已知限制、绕过 JDK/FFM bug 的 workaround。不写 WHAT（方法名已说明），不写 WHO/WHEN（Git 已记录）。

### 4. 性能考量

- **装箱开销**：高强度循环中避免 `IVector.get(i)` 反复装箱。使用 `IDoubleVector.getData()` 或 `IDoubleMatrix.getData()` 获取原始 `double[]` 直接操作。
- **`transpose()` / `t()` / `transposeNew()`**：三者均返回新矩阵（不可变模式）。`t()` 是 `transpose()` 的简写，`transpose()` 委托 `transposeNew()`。需就地修改时用 `transposeInPlace()`（修改原矩阵，谨慎使用）。
- **Double vs Float**：默认使用 Double 精度。仅在内存受限且精度要求不高的大规模场景（如向量索引、嵌入式特征）使用 Float。
- **SIMD**：大规模向量/矩阵运算在 `com.yishape.lab.math.compute` 包中有 SIMD 实现（Java Vector API），调用在 `IMatrix`/`IVector` 的具体实现上层完成。运行时若 Vector API 不可用自动回退 SISD。
- **HPC**：通过 Java FFM 调用 Rust 原生库（Rust 端：`E:\rust_work\yishape_math_rust`，Java 桥接：`E:\work\yishape-math-hpc`，调用封装：`com.yishape.lab.math.compute.hpc`）。HPC 路由在 `IMatrix`/`IVector` 实现的上层，**禁止干扰纯 Java 底层实现**。HPC 不可用时自动回退 SIMD → SISD。
- **行主序存储**：内部矩阵存储为行主序（C order），`data[i][j]` 表示第 i 行第 j 列。

### 5. 技术栈

- Java 25，Maven 4.0.0
- 画图三后端：JavaFX（桌面交互）、ECharts（Web/HTML）、SVG（矢量输出）
- 可选依赖：`yishape-math-hpc`（Rust 原生加速，不随主库传递，需显式声明）
- JVM 参数：SIMD 需 `--add-modules jdk.incubator.vector`；HPC 需 `--enable-native-access=ALL-UNNAMED`
- 禁用 SIMD：`-Dyishape.math.use.simd=false`
