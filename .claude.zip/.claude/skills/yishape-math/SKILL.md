---
name: yishape-math
description: Reference for the yishape-math Java numerical computing library (v0.5.0). Use when writing Java code that needs linear algebra (vector/matrix/decomposition/solve), statistics (distributions/tests/ANOVA), machine learning (classify/regression/cluster/PCA/DML), optimization (L-BFGS/SGD/Adam/LP/MCLP), signal processing (FFT/wavelet/filter), time series (ARIMA/forecast/decompose/cointegration), data visualization (Plots/charts/2D/3D), or vector indexing (ANN/HNSW/LSH). Nine facades: Linalg, DataFrame, Stats, ML, Opts, Signals, TSA, Plots, VI.
---

# YiShape-Math Quick Reference

## Maven

```xml
<dependency>
    <groupId>com.yishape.lab</groupId>
    <artifactId>yishape-math</artifactId>
    <version>0.5.0</version>
</dependency>
```

## Keyword Routing

When the user asks about a specific topic, read only the relevant sub-file(s):

| Keywords in user query | Read |
|---|---|
| vector, matrix, IVector, IMatrix, tensor, solve, decompose, eigen, SVD, QR, LU, Cholesky, sparse, complex, Linalg | [reference/linalg.md](reference/linalg.md) |
| DataFrame, CSV, readCsv, column, slice data, tabular, toMatrix, toCsv | [reference/dataframe.md](reference/dataframe.md) |
| distribution, normal, t-test, chi2, ANOVA, hypothesis, p-value, confidence interval, Stats, pdf, cdf, ppf, GMM, EM | [reference/stats.md](reference/stats.md) |
| classify, classification, regression, cluster, clustering, PCA, t-SNE, UMAP, SVD降维, DML, distance metric, preprocess, scaler, normalize, ML, fit, predict, logistic, randomForest, XGBoost, SVM, KNN, K-Means | [reference/ml.md](reference/ml.md) |
| optimize, optimization, L-BFGS, SGD, Adam, conjugate gradient, linear programming, LP, simplex, integer programming, MCLP, MCQP, objective, gradient, Opts | [reference/optimize.md](reference/optimize.md) |
| signal, FFT, DCT, wavelet, filter, butterworth, kalman, generation, sine wave, noise, SNR, PSD, spectrum, Signals | [reference/signals.md](reference/signals.md) |
| time series, ARIMA, forecast, Holt-Winters, GARCH, decompose, STL, seasonal, trend, cointegration, TSA | [reference/timeseries.md](reference/timeseries.md) |
| plot, chart, visualize, histogram, scatter, bar, pie, heatmap, line chart, candlestick, 3D, style, theme, SVG, ECharts, JavaFX, Plots, IPlot | [reference/plot.md](reference/plot.md) |
| ANN, nearest neighbor, HNSW, LSH, vector index, search, PQ, product quantization, KD-Tree, VI, VecIdx, distance metric search | [reference/vecidx.md](reference/vecidx.md) |
| pattern, example, workflow, pipeline, how to combine, data→train→evaluate | [examples/patterns.md](examples/patterns.md) |
| performance, HPC, SIMD, SISD, backend, JVM flags, design rules, RereMathUtil, fast, speed, benchmark | [guide.md](guide.md) |

## Nine Facades

| Facade | Import | Creates/Does |
|--------|--------|-------------|
| `Linalg` | `com.yishape.lab.math.linalg.Linalg` | Vectors, matrices, tensors, sparse, complex, decompositions, solvers |
| `DataFrame` | `com.yishape.lab.math.data.DataFrame` | `DataFrame.readCsv(path)` — tabular data, slicing, CSV I/O |
| `Stats` | `com.yishape.lab.math.stats.Stats` | `Stats.norm(0,1)`, `Stats.tester`, `Stats.anova`, `Stats.corr()` |
| `ML` | `com.yishape.lab.math.ml.ML` | Via sub-fields: `.clf`, `.reg`, `.dr`, `.clu`, `.dml`, `.preproc` |
| `Opts` | `com.yishape.lab.math.optimize.Opts` | `Opts.lbfgs()`, `Opts.simplexLinProgSolver()`, `.mclp`, `.mcqp` |
| `Signals` | `com.yishape.lab.math.signal.Signals` | Via sub-fields: `.gen`, `.filt`, `.xform`, `.analyze` |
| `TSA` | `com.yishape.lab.math.timeseries.TSA` | `TSA.data()`, sub-fields: `.forecast`, `.filter`, `.decompose`, `.cointegrate` |
| `Plots` | `com.yishape.lab.math.plot.Plots` | `Plots.of(800,600).line(x,y).show()` — 2D/3D, JavaFX/ECharts/SVG |
| `VI` | `com.yishape.lab.math.vecidx.VI` | `VI.buildDouble(data, ids, options)` — HNSW, LSH, PQ, KD-Tree |

## Core Types

- **`IVector<T>`** / **`IDoubleVector`** / **`IFloatVector`** — 1D math + stats + slicing
- **`IMatrix<T>`** / **`IDoubleMatrix`** / **`IFloatMatrix`** — 2D math + decompositions + solve
- **`ITensor`** — N-dimensional double tensor
- **`IComplexMatrix`** + **`IComplexVector`** — complex numbers
- **`ISparseMatrix`** — sparse double (COO/CSR/CSC)

## Essential Patterns (memorize these)

```java
// Creation — ALWAYS use Linalg, never `new`
var v = Linalg.vector(new double[]{1, 2, 3});
var m = Linalg.matrix(new double[][]{{1,2},{3,4}});
var M = Linalg.randn(100, 50);

// Operations are fluent (return new instances)
var result = m.transpose().mmul(M).add(Linalg.eye(50));

// Decompositions via instance methods
var eigen = m.eigen();        // Tuple2<IVector, IMatrix> = (values, vectors)
var svd   = m.svd();          // Tuple3<IMatrix, IVector, IMatrix> = (U, S, V)
var qr    = m.qr();           // Tuple2<IMatrix, IMatrix> = (Q, R)

// Solve Ax = b
var x = m.solve(b);

// ML pipelines via sub-facades
var model = ML.reg.linear(0, 0.1).fit(X, y);     // Ridge regression
var preds = ML.clf.randomForest().fit(X, labels).predictBatch(X_test);
var reduced = ML.dr.pca(2).fitTransform(data);
var scaled = ML.preproc.standardScaler().fitTransform(data);

// Stats
var dist = Stats.norm(0, 1);
double p = dist.cdf(1.96);
var test = Stats.tester.testMeanEqualWithT(0, sample, 0.95);

// Optimize
var opt = Opts.lbfgs().optimize(initX, objFun, gradFun);

// Plot
Plots.of(800, 600).scatter(x, y, "ro").title("Title").show();

// Vector search
var idx = VI.buildDouble(data, ids, new EuclideanMetric(), options);
var hits = idx.search(query, 10);
```

## Key Rules

- **Never** `new RereDoubleMatrix(...)` — always use `Linalg` factories
- **Never** import common-math/jblas in algorithm code
- **LP solvers minimize** by default — negate `c` for maximization
- **Column-major** internal storage (Fortran order)
- **Generic `<T extends Number>`** APIs with `Double`/`Float` specializations via covariant sub-interfaces
- **HPC auto-fallback**: if `yishape-math-hpc` not on classpath or native libs unavailable, silently falls to SIMD → SISD
