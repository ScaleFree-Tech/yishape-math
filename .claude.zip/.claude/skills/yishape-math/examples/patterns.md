# Common Usage Patterns

## Pattern 1: Data → Train → Evaluate (ML Pipeline)

```java
// Read and prepare
var df = DataFrame.readCsv("iris.csv", ",", true);
var features = df.sliceColumn(0, -1).toMatrix();       // all but last column
var labels = df.getColumn(-1).toStringArray();          // last column as labels

// Train
var clf = ML.clf.randomForest();
clf.fit(features, labels);

// Evaluate
var preds = clf.predictBatch(features);
var metrics = ML.clf.classificationMetrics(clf, features, labels);
var cv = ML.clf.kFoldCrossValidation(clf, features, labels, 5);
System.out.println(cv);        // cross-validation scores
System.out.println(metrics);   // precision, recall, F1, accuracy
```

## Pattern 2: Preprocess → Reduce → Cluster

```java
// Scale
var scaler = ML.preproc.standardScaler();
var scaled = scaler.fitTransform(features);

// Reduce
var pca = ML.dr.pca(10);
var reduced = pca.fitTransform(scaled);

// Cluster
var km = ML.clu.kMeans(5).fit(reduced);
var labels = km.getLabels();
var quality = km.evaluateQuality();   // silhouette, inertia
```

## Pattern 3: Optimize Objective (L-BFGS)

```java
IObjectiveFunction obj = x -> {
    double x1 = x.get(0).doubleValue(), x2 = x.get(1).doubleValue();
    return (1 - x1) * (1 - x1) + 100 * (x2 - x1 * x1) * (x2 - x1 * x1);  // Rosenbrock
};
IGradientFunction grad = x -> {
    double x1 = x.get(0).doubleValue(), x2 = x.get(1).doubleValue();
    return Linalg.vector(new double[]{
        -2 * (1 - x1) - 400 * x1 * (x2 - x1 * x1),
        200 * (x2 - x1 * x1)
    });
};

var result = Opts.lbfgs().optimize(Linalg.zeros(2), obj, grad);
System.out.println("Optimal: " + result.getOptimalPoint());
System.out.println("Value: " + result.getOptimalValue());
```

## Pattern 4: Matrix Decomposition Pipeline

```java
var A = Linalg.randn(100, 50);

// SVD
var svd = A.svd();                     // Tuple3<IMatrix, IVector, IMatrix>
var U = svd.get1();
var S = svd.get2();
var V = svd.get3();
var reconstructed = U.mmul(Linalg.diag(S)).mmul(V.transpose());

// Solve linear system
var b = Linalg.randn(100);
var x = A.solve(b);                    // Ax = b via QR/LU

// Eigen decomposition
var eigen = A.transpose().mmul(A).eigen();  // AᵀA is symmetric
var eigenvalues = eigen.get1();
var eigenvectors = eigen.get2();
```

## Pattern 5: Signal Processing Pipeline

```java
// Generate
var clean = Signals.gen.sineWave(1000, 10, 1000, 1, 0);
var noisy = Signals.gen.addNoise(clean, SignalType.WHITE_NOISE,
    new SignalParameters().setPower(0.1));

// Filter
var filtered = Signals.filt.butterworthLowPass(noisy, 50, 1000, 4);

// Analyze
var snr = Signals.analyze.signalToNoiseRatio(clean, filtered);
var psd = Signals.analyze.powerSpectralDensity(filtered, 256, 0.5, 1000);

// Visualize
Plots.of(800, 400)
    .line(clean, "b-")      // blue = original
    .line(noisy, "r-")      // red = noisy
    .line(filtered, "g-")   // green = filtered
    .title("Signal Processing")
    .legend()
    .show();
```

## Pattern 6: Time Series Forecast & Decompose

```java
var values = Linalg.vector(new double[]{10, 12, 13, 15, 18, 20, 22, 25, 28, 30});
var ts = TSA.data(values, "sales");

// Decompose
var decomp = TSA.decompose.classical(values, 4, DecompositionModel.ADDITIVE);
System.out.println("Trend: " + decomp.getTrend());
System.out.println("Seasonal: " + decomp.getSeasonal());

// Forecast
var forecast = TSA.forecast.arima(values, 2, 1, 1, 3, 0.95);
System.out.println("Forecast: " + forecast.getForecast());
System.out.println("95% CI lower: " + forecast.getLowerBounds());
System.out.println("95% CI upper: " + forecast.getUpperBounds());
```

## Pattern 7: Linear Programming

```java
// minimize 2x₁ + 3x₂  subject to x₁ + x₂ = 5, x₁ ≥ 0, x₂ ≥ 0
var c = Linalg.vector(new double[]{2.0, 3.0});
var A_eq = Linalg.matrix(new double[][]{{1.0, 1.0}});
var b_eq = Linalg.vector(new double[]{5.0});

var solver = Opts.simplexLinProgSolver();
var result = solver.solveEq(c, A_eq, b_eq);

System.out.println("x* = " + result.getOptimalPoint());
System.out.println("f* = " + result.getOptimalValue());
```

## Pattern 8: Distance Metric Learning → k-NN

```java
// Learn a diagonal metric (automatic feature selection)
var dml = ML.dml.diagDml(0.1, 0.01).fit(features, labels);

// Transform data through learned metric
var transformed = dml.transform(features);

// Use the metric directly for distance computations
var metricMatrix = dml.transformMatrix();
// metricMatrix is a diagonal matrix M where distance² = (x-y)ᵀM(x-y)

// Classify using transformed space with k-NN
var knn = ML.clf.kNN(5);
knn.fit(transformed, labels);
var prediction = knn.predict(newSample);
```

## Pattern 9: Vector Index → ANN Search

```java
double[][] vectors = /* your data */;
String[] ids = /* your IDs */;

var options = new VecSearchOption();
// options auto-detects best index type; can set .setEfConstruction(200) etc.

var idx = VI.buildDouble(vectors, ids, new EuclideanMetric(), options);

// Search
var query = Linalg.vector(new double[]{0.5, 0.3, ...});
var hits = idx.search(query, 10);  // top-10 nearest

for (var hit : hits) {
    System.out.println(hit.getId() + " -> " + hit.getScore());
}
```

## Pattern 10: Full Visualization Dashboard

```java
var x = Linalg.linspace(0, 2 * Math.PI, 100);
var y = x.sin();

Plots.of(1000, 600)
    .line(x, y, "b-")
    .scatter(x, y.multiplyScalar(0.5), "ro")
    .title("Dashboard", "Sine wave with derived series")
    .xlabel("x")
    .ylabel("y")
    .setPalette("matplotlib")
    .legend()
    .saveAsHtml("dashboard.html");

// SVG for vector graphics
Plots.ofSvg(800, 600)
    .line(x, y, "r-")
    .title("SVG Export")
    .saveAsSvg("chart.svg");
```
