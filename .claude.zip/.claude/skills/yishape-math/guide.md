# Performance & Design Guide

## Execution Backends (Auto-Selected)

| Backend | Mechanism | Activation |
|---------|-----------|------------|
| **SISD** | Pure Java scalar | Always available (fallback) |
| **SIMD** | Java Vector API (incubator) | JVM flag: `--add-modules jdk.incubator.vector` |
| **HPC** | Rust native via FFM | Dependency: `yishape-math-hpc`, JVM flag: `--enable-native-access=ALL-UNNAMED` |

HPC failure auto-fallback: if native libs unavailable, silently falls back to Java SIMD → SISD.

```bash
# SIMD
java --add-modules jdk.incubator.vector -jar app.jar

# HPC
java --enable-native-access=ALL-UNNAMED -jar app.jar

# Force scalar (disable SIMD)
java -Dyishape.math.use.simd=false -jar app.jar
```

## Maven Dependencies

```xml
<!-- Core (required) -->
<dependency>
    <groupId>com.yishape.lab</groupId>
    <artifactId>yishape-math</artifactId>
    <version>0.5.0</version>
</dependency>

<!-- HPC (optional, same version as core) -->
<dependency>
    <groupId>com.yishape.lab</groupId>
    <artifactId>yishape-math-hpc</artifactId>
    <version>0.5.0</version>
</dependency>
```

## Critical Design Rules (from CLAUDE.md)

1. **Never** use `new RereDoubleMatrix(...)` — always `Linalg.matrix(...)` or `IMatrix.of(...)`
2. **Never** call third-party math libs (common-math, jblas, etc.) in algorithm implementations
3. **Interface/implementation separation**: all APIs return `IVector`, `IMatrix`, etc. Concrete types are internal
4. **Fluent API**: most operations return new instances (immutable). Use `t()` for in-place transpose
5. **Column-major layout**: internal storage is Fortran order for BLAS3 compatibility
6. **LP solvers minimize by default** — negate objective `c` for maximization

## Type-Specific APIs

Generic `<T extends Number>` throughout, but covariant sub-interfaces provide primitive access:

```java
IDoubleVector dv = Linalg.vector(new double[]{1, 2, 3});
double[] raw = dv.getData();    // zero-copy access for performance loops

IFloatVector fv = Linalg.vector(new float[]{1, 2, 3});
float[] fraw = fv.getData();
```

## Performance Tips

- **Batch operations**: chain vector/matrix operations rather than manual loops — the library fuses operations internally
- **Primitive loops**: for very hot paths, use `getData()` to access the raw `double[]`/`float[]` and loop manually
- **SIMD**: enable with `--add-modules jdk.incubator.vector` for 2-10x speedup on large matrices
- **HPC**: enable for SVD, GEMM, LP at massive scale (3-12x vs pure Java)
- **Sparse**: use `ISparseMatrix` for matrices with >80% zeros

## Important Package Map

| Need | Class/Import |
|------|-------------|
| Matrix & vector | `com.yishape.lab.math.linalg.Linalg` |
| DataFrame | `com.yishape.lab.math.data.DataFrame` |
| Distributions & tests | `com.yishape.lab.math.stats.Stats` |
| ML models | `com.yishape.lab.math.ml.ML` |
| Optimization | `com.yishape.lab.math.optimize.Opts` |
| Signal processing | `com.yishape.lab.math.signal.Signals` |
| Time series | `com.yishape.lab.math.timeseries.TSA` |
| Plotting | `com.yishape.lab.math.plot.Plots` |
| Vector search | `com.yishape.lab.math.vecidx.VI` |
| Math utilities | `com.yishape.lab.math.RereMathUtil` |
| .npy file I/O | `com.yishape.lab.math.util.NpyArrayIO` |
| Complex numbers | `com.yishape.lab.math.core.Complex` |

## Math Utilities (RereMathUtil)

```java
// Type conversion
RereMathUtil.doubleToFloat(double[])   RereMathUtil.floatToDouble(float[])
RereMathUtil.intToDouble(int[])        RereMathUtil.toPrimitive(T[])
RereMathUtil.toClassArray(double[])    // for 1D and 2D arrays

// Random
RereMathUtil.generateRandomFloats(int length)
RereMathUtil.generateRandomFloats(long seed, int length)
RereMathUtil.generateRandomInts(int min, int max, int length)
RereMathUtil.normalSample(double mean, double std)

// Special functions
RereMathUtil.gamma(double x)           RereMathUtil.beta(double a, double b)
RereMathUtil.incompleteGamma(...)      RereMathUtil.incompleteBeta(...)
RereMathUtil.erf(double x)             RereMathUtil.inverseNormalCDF(double p)

// Combinatorics
RereMathUtil.factorial(int n)          RereMathUtil.logFactorial(int n)
RereMathUtil.combination(int n, int k) RereMathUtil.logCombination(int n, int k)
RereMathUtil.stirlingNumber2(int n, int k)

// Convenience
RereMathUtil.sigmoid(double x)
RereMathUtil.isClose(double a, double b)
```

## Numerical Validation Against Standard Libraries

The library has been benchmarked against NumPy (BLAS/LAPACK) and Common-Math4:

| Operation | vs CM4 | vs NumPy | HPC vs SISD |
|-----------|--------|----------|-------------|
| SVD (1000x1000) | 3.3x faster | competitive | 12x faster |
| GEMM (1000x1000) | 14.5x faster | ~5x slower | 4x faster |
| Cholesky (500x500) | 2.7x faster | 2.3x faster | — |
| LU (500x500) | 1.2x faster | competitive | 1.5x faster |
| LP (2000x4000) | — | — | 11.7x faster |

Test env: Java 25, Intel i7-13700H, DDR5-5600.
