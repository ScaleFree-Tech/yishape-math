# DataFrame — Tabular Data Reference

**Import:** `com.yishape.lab.math.data.DataFrame`

## Static Factories

```java
DataFrame.readCsv(String filePath)                                      → DataFrame
DataFrame.readCsv(String filePath, String separator, boolean hasHeader) → DataFrame
```

## Instance Methods

```java
// --- Column access ---
df.get(int colIndex)                         → Column
df.getColumnByName(String name)              → Column
df.getColumn(int index)                      → Column (supports negative)
df.addColumn(Column col)                     → void
df.removeColumn(int index)                   → void

// --- Slicing ---
df.slice(String rowExpr, String colExpr)     → DataFrame   // e.g. "1:3", "0:2"; null = all
df.sliceColumn(int start, int end)           → DataFrame
df.sliceColumn(int start, int end, int step) → DataFrame

// --- Properties ---
df.shape()       → Tuple2<Integer, Integer>
df.getRowCount() → int
df.getColumnCount() → int
df.getColumnNames() → List<String>
df.getColumnTypes() → List<ColumnType>
df.isEmpty()     → boolean

// --- Conversion & I/O ---
df.toMatrix()    → IMatrix<Double>    // only numeric columns
df.toCsv(String filePath)             → void
df.copy()        → DataFrame
df.clear()       → void
```

## Column Methods

```java
col.toVec()          → IVector<Double>
col.toStringList()   → List<String>
col.toStringArray()  → String[]
col.getName()        → String
col.setName(String)  → void
col.getColumnType()  → ColumnType
col.setColumnType(ColumnType)  → void
col.getData()        → List<?>
col.setData(List<?>) → void
```
