# Linalg — Linear Algebra Reference

**Import:** `com.yishape.lab.math.linalg.Linalg`

## Core Type System

- `IVector<T extends Number>` → `IDoubleVector`, `IFloatVector`
- `IMatrix<T extends Number>` → `IDoubleMatrix`, `IFloatMatrix`, `IMatrixView<T>`
- `ITensor` — N-dimensional double tensor
- `IComplexMatrix` + `IComplexVector` — complex numbers
- `ISparseMatrix` — sparse double (COO/CSR/CSC)

## Vector Creation (Linalg static factories)

```java
// From data
Linalg.vector(double[] data)                              → IDoubleVector
Linalg.vector(Double[] data)                              → IDoubleVector
Linalg.vector(float[] data)                               → IFloatVector
Linalg.vector(Float[] data)                               → IFloatVector
Linalg.vector(int[] data)                                 → IVector<T>
Linalg.vector(double value)                               → IDoubleVector (scalar)
Linalg.vector(double v1, double v2)                       → IDoubleVector (2-element)

// Filled
Linalg.zeros(int len)                                     → IDoubleVector
Linalg.ones(int len)                                      → IDoubleVector
Linalg.ones(int len, Class<T> type)                       → IVector<T>
Linalg.zeros(int len, Class<T> type)                      → IVector<T>

// Ranges
Linalg.range(int end)                                     → IDoubleVector  // [0, 1, ..., end-1]
Linalg.range(int start, int end)                          → IDoubleVector
Linalg.range(int start, int end, int step)                → IDoubleVector
Linalg.range(int start, int end, int step, Class<T> type) → IVector<T>

// Random
Linalg.rand(int length)                                   → IDoubleVector  // uniform [0,1)
Linalg.randn(int length)                                  → IDoubleVector  // N(0,1)
Linalg.randn(int length, double mean, double std)         → IDoubleVector
Linalg.linspace(double start, double stop, int num)       → IDoubleVector
Linalg.logspace(double start, double stop, int num)       → IDoubleVector
```

## Matrix Creation (Linalg static factories)

```java
// From data
Linalg.matrix(double[][] data)                            → IDoubleMatrix
Linalg.matrix(float[][] data)                             → IFloatMatrix
Linalg.matrix(Double[][] data)                            → IDoubleMatrix
Linalg.matrix(Float[][] data)                             → IFloatMatrix
Linalg.matrixFromDoubleList(List<double[]> data)          → IDoubleMatrix
Linalg.matrixFromFloatList(List<float[]> data)            → IFloatMatrix

// Filled
Linalg.zeros(int rows, int cols)                          → IDoubleMatrix
Linalg.ones(int rows, int cols)                           → IDoubleMatrix
Linalg.eye(int size)                                      → IDoubleMatrix
Linalg.eye(int size, Class<T> type)                       → IMatrix<T>

// Random
Linalg.rand(int rows, int cols)                           → IDoubleMatrix
Linalg.randn(int rows, int cols)                          → IDoubleMatrix
Linalg.randn(int rows, int cols, double mean, double std) → IDoubleMatrix

// Diagonal & special
Linalg.diag(double[] diagonal)                            → IDoubleMatrix
Linalg.diag(IVector diagonal)                             → IMatrix<T>
Linalg.fromArray(double[] data, int rows, int cols)       → IDoubleMatrix
Linalg.lowerTriMatrix(int m)                              → IDoubleMatrix
Linalg.lowerTriMatrix(int m, double[][] values)           → IDoubleMatrix
Linalg.upperTriMatrix(int m)                              → IDoubleMatrix
Linalg.upperTriMatrix(int m, double[][] values)           → IDoubleMatrix
Linalg.unitLowerTriMatrix(int m, double[][] values)       → IDoubleMatrix
Linalg.bidiagonalMatrix(int n, double[] diag, double[] supDiag) → IDoubleMatrix
Linalg.tridiagonalMatrix(int n, double[] sub, double[] diag, double[] sup) → IDoubleMatrix
Linalg.blockDiagonalMatrix(IMatrix<Double>[] matrices)    → IMatrix<Double>
Linalg.permutationMatrix(int size, int[] pivot)           → IDoubleMatrix

// Stacking & consolidation
Linalg.stack(int axis, IMatrix<T>... matrices)            → IMatrix<T>
Linalg.multiDot(IMatrix<Double>... matrices)              → IMatrix<Double>
Linalg.kron(IMatrix<T> a, IMatrix<T> b)                   → IMatrix<T>
Linalg.average(IMatrix<T>... matrices)                    → IMatrix<T>

// I/O
Linalg.load(String filename)                              → IMatrix<Double>
matrix.save(String path)                                   // instance method
```

## IVector Instance Methods

```java
// --- Arithmetic (fluent, return new instance) ---
v.add(v2)          v.sub(v2)         v.multiply(v2)      // element-wise
v.addScalar(s)     v.multiplyScalar(s)  v.divideByScalar(s)
v.dot(v2)          v.innerProduct(v2)                     // same = Σ aᵢbᵢ
v.outer(v2)        v.mmul(v2)                             // matrix multiply (2D result)

// --- Math ---
v.square()  v.sqrt()  v.exp()  v.log()  v.abs()
v.sin()  v.cos()  v.tan()  v.round()  v.floor()  v.ceil()
v.sign()

// --- Statistics ---
v.sum()  v.mean()  v.median()  v.var()  v.std()  v.std(int ddof)
v.min()  v.max()  v.argMin()  v.argMax()
v.norm1()  v.norm2()  v.normInf()
v.skewness()  v.kurtosis()  v.ptp()

// --- Slicing & Indexing ---
v.slice(int start)                    // [start, end)
v.slice(int start, int end)           // half-open [start, end)
v.slice(int start, int end, int step)
v.slice(String expr)                  // "1:5", "2:", ":5", "::2", "-3:", ":-2", "::-1"
v.fancyGet(int[] indices)             // integer array indexing (supports negative)
v.booleanGet(boolean[] mask)          // boolean mask indexing
v.get(int i)                          // single element (supports negative index)
v.set(int i, T val)

// --- Distance & Similarity ---
v.euclideanDistance(v2)   v.manhattanDistance(v2)   v.cosineSimilarity(v2)

// --- Other ---
v.where(IVector condition, IVector other)     // element-wise conditional
v.repeat(int times)       v.tile(int times)
v.copy()   v.clip(min, max)   v.fill(value)
v.cumsum()  v.cumprod()  v.diff()  v.diff(int order)
v.normalize()
v.logicalAnd(v2)  v.logicalOr(v2)  v.logicalNot()
v.length()  v.isEmpty()
v.toArray() → T[]
```

## IMatrix Instance Methods

```java
// --- Arithmetic ---
m.add(m2)   m.sub(m2)    m.mmul(m2)          // matrix multiply (A @ B)
m.mmul(double scalar)                         // scalar multiply
m.multiply(m2)                                // Hadamard (element-wise)
m.transpose()  m.t()                          // t() is in-place, transpose() returns new
m.transposeNew()                              // always new copy
m.frobeniusInnerProduct(m2)                   // Σ Aᵢⱼ Bᵢⱼ (like np.sum(A*B))

// --- Decompositions (computed on demand + cached) ---
m.eigen()  → Tuple2<IVector<Double>, IMatrix<Double>>  // (eigenvalues, eigenvectors)
m.svd()    → Tuple3<IMatrix<Double>, IVector<Double>, IMatrix<Double>>  // (U, S, V)
m.qr()     → Tuple2<IMatrix<Double>, IMatrix<Double>>  // (Q, R)
m.lu()     → Tuple2<IMatrix<Double>, IMatrix<Double>>  // (L, U)
m.cholesky()  → IMatrix<Double>   // L where A = LLᵀ
m.schur()  → ISchurDecomposition
m.hessenberg()  → IHessenbergDecomposition
m.bidiagonal()  → IBidiagonalDecomposition

// --- Solving ---
m.solve(IVector<Double> b)  → IVector<Double> x    // Ax = b
m.inv()   → IMatrix<T>       // inverse
m.pinv()  → IMatrix<T>       // pseudo-inverse (SVD-based)
m.det()   → double            // determinant
m.rank()  → int
m.cond()  → double            // condition number
m.trace() → T
m.isSquare()  m.isSymmetric()  m.isPositiveDefinite()

// --- Slicing ---
m.sliceRows(int start, int end)            m.sliceColumns(int start, int end)
m.slice(String rowExpr, String colExpr)    // e.g. "1:3", "0:2"
m.getRow(int i)  → IVector<T>              m.getColumn(int j)  → IVector<T>
m.getColumnMatrix(int j)  → IMatrix<T>
m.get(int i, int j)  → T                   m.put(int i, int j, T val)
m.getRows(int... indices) → IMatrix<T>     m.getColumns(int... indices) → IMatrix<T>
m.setColumn(int j, IVector val)

// --- Stats ---
m.rowSums()  m.rowMeans()  m.colSums()  m.colMeans()
m.sum()  m.mean()  m.var()  m.std()  m.min()  m.max()

// --- Transform ---
m.center()  m.covariance()  m.covarianceFromCentered()
m.normalizeRows()  m.normalizeColumns()
m.reshape(int rows, int cols)   m.flatten() → IVector<T>

// --- Stacking ---
m.hstack(IMatrix m2)   m.vstack(IMatrix m2)
m.hsplit(int[] cols)   m.vsplit(int[] rows)

// --- Math ---
m.pow(double exp)  m.sqrt()  m.exp()  m.log()  m.abs()  m.sign()
m.sin()  m.cos()  m.tan()  m.sinh()  m.cosh()  m.tanh()

// --- Properties ---
m.rows()  m.cols()  m.shape() → Tuple2<Integer, Integer>
m.frobeniusNorm()  m.frobeniusDistance(IMatrix other)
```

## Linear Solvers & Utilities (Linalg static)

```java
Linalg.solve(IMatrix<Double> A, IVector<Double> b)        → IVector<Double>
Linalg.lstsq(IMatrix<Double> A, IVector<Double> b)        → Tuple2<IVector, Double>
Linalg.lstsq(IMatrix<Double> A, IMatrix<Double> B)        → Tuple2<IMatrix, Double>
Linalg.forwardSolve(IMatrix<T> L, IMatrix<T> B)           → IMatrix<T>
Linalg.backwardSolve(IMatrix<T> U, IMatrix<T> B)          → IMatrix<T>
Linalg.solveLinearSystem(IMatrix<T> A, IMatrix<T> B)      → IMatrix<T>
Linalg.solveLinearSystem(IMatrix<T> A, IVector<T> b)      → IVector<T>
Linalg.permuteRows(IMatrix<T> m, int[] rowIndices)        → IMatrix<T>
Linalg.permuteColumns(IMatrix<T> m, int[] colIndices)     → IMatrix<T>
Linalg.meshgrid(IVector<Double> x, IVector<Double> y)     → Tuple2<IMatrix, IMatrix>
Linalg.interp(IVector<Double> xq, IVector<Double> xp, IVector<Double> fp) → IVector<Double>
```

## Complex Matrix/Vector

```java
Linalg.complexMatrix(double[][] real, double[][] imag)   → IComplexMatrix
Linalg.complexMatrix(Complex[][] data)                    → IComplexMatrix
Linalg.complexMatrixFromPolar(double[][] mag, double[][] phase) → IComplexMatrix
Linalg.complexZeros(int rows, int cols)                   → IComplexMatrix
Linalg.complexOnes(int rows, int cols)                    → IComplexMatrix
Linalg.complexEye(int size)                               → IComplexMatrix
Linalg.complexDiag(Complex[] diagonal)                    → IComplexMatrix
Linalg.complexVector(double[] real, double[] imag)        → IComplexVector
Linalg.complexVector(Complex[] data)                      → IComplexVector
Linalg.complexVectorFromPolar(double[] mag, double[] phase) → IComplexVector
```

## Sparse Matrix

```java
Linalg.sparse(double[][] data)                            → ISparseMatrix
Linalg.sparse(double[][] data, double tolerance)          → ISparseMatrix
Linalg.sparseFromCOO(int[] rowIdx, int[] colIdx, double[] vals, int rows, int cols)
Linalg.sparseFromCSR(int[] rowPtr, int[] colInd, double[] vals, int rows, int cols)
Linalg.sparseFromCSC(int[] rowInd, int[] colPtr, double[] vals, int rows, int cols)
Linalg.sparseEye(int size)                                → ISparseMatrix
Linalg.sparseEye(int rows, int cols)                      → ISparseMatrix
Linalg.sparseDiag(double[] values)                        → ISparseMatrix
Linalg.diagonalSparse(double[] diagonal)                  → ISparseMatrix
Linalg.tridiagonalSparse(double[] lower, double[] main, double[] upper)
Linalg.identitySparse(int size)                           → ISparseMatrix
Linalg.zeroSparse(int rows, int cols)                     → ISparseMatrix
```

## Tensor

```java
Linalg.tensor(double[] data, int... shape)   → ITensor
Linalg.tensor(double[][] data)               → ITensor
Linalg.tensor(double[][][] data)             → ITensor
Linalg.ones(int... shape)                    → ITensor
Linalg.zeros(int... shape)                   → ITensor
Linalg.rand(int... shape)                    → ITensor
Linalg.randn(int... shape)                   → ITensor
Linalg.eye(int n, int... extraDims)          → ITensor
```
