# ML — Machine Learning Reference

**Import:** `com.yishape.lab.math.ml.ML`

All functionality accessed via sub-facade fields:

```java
ML.clf      // ClfWrapper — classifiers
ML.reg      // RegWrapper — regression
ML.dr       // DrWrapper — dimensionality reduction
ML.clu      // CluWrapper — clustering
ML.dml      // DmlWrapper — distance metric learning
ML.preproc  // PreprocWrapper — preprocessing/scaling
```

---

## ML.clf — Classification

### Factory Methods

```java
ML.clf.logisticRegression()                                → IClassifier
ML.clf.logisticRegression(double l1Weight, double l2Weight) → IClassifier
ML.clf.randomForest()                                      → IClassifier
ML.clf.xGboost()                                           → IClassifier
ML.clf.kNN(int k)                                          → IClassifier
ML.clf.decisionTree()                                      → IClassifier
ML.clf.decisionTree(DecisionTreeCriterion criterion, int maxDepth,
    int minSamplesSplit, int minSamplesLeaf)                → IClassifier
ML.clf.linearSvm()                                         → IClassifier
ML.clf.linearSvm(double C, boolean standardizeFeatures)    → IClassifier
ML.clf.ensembleClassifier(EnsembleStrategy strategy, long seed) → IClassifier
ML.clf.ensembleClassifier(EnsembleStrategy strategy, double[] weights, long seed) → IClassifier
// EnsembleStrategy: VOTING, WEIGHTED_VOTING, STACKING
```

### IClassifier Interface

```java
classifier.fit(IMatrix features, String[] labels)  → ClfResult
classifier.predict(IVector features)               → String
classifier.predictProb(IVector features)           → double[]
classifier.predictBatch(IMatrix features)          → String[]
classifier.predictBatchWithProbs(IMatrix features) → BatchPredResult
classifier.isTrained()                             → boolean
classifier.getResult()                             → ClfResult
classifier.setLearningRate(double)                 // for LR
classifier.setMaxIterations(int)
classifier.setTolerance(double)
classifier.setRegularization(double l1, double l2)
```

### Evaluation Utilities (static on ClfWrapper)

```java
ML.clf.classificationMetrics(IClassifier model, IMatrix feature, String[] trueLabels) → ClassificationMetrics
ML.clf.kFoldCrossValidation(IClassifier clf, IMatrix<Double> X, String[] y, int k) → CrossValidationResult
ML.clf.kFoldCrossValidation(IClassifier clf, IMatrix<Double> X, String[] y, int k,
    CrossValidationLogger logger) → CrossValidationResult
ML.clf.saveClassifier(IClassifier clf, String path)
ML.clf.loadClassifier(String path) → IClassifier
```

---

## ML.reg — Regression

```java
ML.reg.linear()                                       → IRegression
ML.reg.linear(double lambda1, double lambda2)         → IRegression
ML.reg.linear(boolean includeBias, double l1, double l2) → IRegression
// lambda1>0 → L1, lambda2>0 → L2, both>0 → ElasticNet

// IRegression interface
reg.fit(IMatrix features, IVector labels)  → RegressionResult
reg.predict(IVector features)              → double
reg.predictBatch(IMatrix features)         → IVector<Double>
reg.isTrained()                            → boolean
reg.getResult()                            → RegressionResult
// RegressionResult: getWeights(), getLoss(), getR2Score(), getAdjustedR2Score(), getIntercept()
```

---

## ML.dr — Dimensionality Reduction

```java
ML.dr.pca(int nComponents)             → ITransform<Double>
ML.dr.svd(int nComponents)             → ITransform<Double>
ML.dr.tsne(int nComponents)            → ITransform<Double>
ML.dr.umap(int nComponents)            → ITransform<Double>
ML.dr.fa(int nFactors)                 → ITransform<Double>
ML.dr.nmf(int nComponents)             → ITransform<Double>
ML.dr.kernelPca(int nComponents)       → ITransform<Double>
ML.dr.kernelPca(KernelType kernel, int nComponents, double gamma) → ITransform<Double>

// ITransform interface
t.fit(IMatrix data)            → void
t.transform(IMatrix data)      → IMatrix<Double>
t.fitTransform(IMatrix data)   → IMatrix<Double>    // combined
t.ifTrained()                  → boolean
t.setParameters(Map<String,Object> params)  → void

// Common setParameters keys:
// t-SNE: "perplexity" (default 30), "learningRate" (200), "maxIterations" (1000)
// UMAP: "nNeighbors" (15), "minDist" (0.1), "metric" ("euclidean")
```

---

## ML.clu — Clustering

```java
ML.clu.kMeans()                                     → IClustering
ML.clu.kMeans(int numClusters)                      → IClustering
ML.clu.kMeans(long randomSeed)                      → IClustering
ML.clu.kMeans(int numClusters, long randomSeed)     → IClustering
ML.clu.gmm()                                        → IClustering
ML.clu.gmm(int numClusters)                         → IClustering

// IClustering interface
clu.fit(IMatrix data)                  → IClustering
clu.fitPredict(IMatrix data)           → int[]
clu.predict(IVector point)             → int
clu.getClusterCenters()                → List<IVector>
clu.getLabels()                        → int[]
clu.getNumClusters()                   → int
clu.getInertia()                       → double
clu.isConverged()                      → boolean
clu.setParameters(Map<String,Object>)  → void
clu.evaluateQuality()                  → ClusteringMetrics  // silhouette, inertia, etc.

// Evaluation
ML.clu.clusteringMetrics(IClustering model, IMatrix data) → ClusteringMetrics
ML.clu.saveClustering(IClustering clustering, String path)
ML.clu.loadClustering(String path) → IClustering
```

---

## ML.dml — Distance Metric Learning

### Proprietary DDML (published INFORMS J. Computing 2025)

```java
ML.dml.diagDml()                                    → ISupervisedDml
ML.dml.diagDml(double elasticTotalWeight)           → ISupervisedDml
ML.dml.diagDml(double l1Weight, double l2Weight)    → ISupervisedDml
ML.dml.diagDml(double l1Weight, double l2Weight, int maxTriplets) → ISupervisedDml
```

### Classic Supervised DML

```java
ML.dml.nca()   ML.dml.nca(int rank, int maxIter, double lr)
ML.dml.lmnn()  ML.dml.lmnn(int rank, int neighbors, double margin)
ML.dml.itml()  ML.dml.itml(double gamma, int maxIter)
ML.dml.dmleig()  ML.dml.dmleig(double mu, int maxIter)
ML.dml.mcml()  ML.dml.mcml(int rank, int maxIter, double lr)
ML.dml.ldmlPairwise()  ML.dml.ldmlPairwise(int rank, int maxSteps)
ML.dml.gmml()  ML.dml.gmml(double geodesicStep, double reg)
ML.dml.dmlmj()  ML.dml.dmlmj(Integer numDims, int nNeighbors)
ML.dml.cmoml()  ML.dml.cmoml(Integer numDims, double reg)
ML.dml.anmm()  ML.dml.anmm(Integer numDims, int nFriends, int nEnemies)
ML.dml.llda()  ML.dml.llda(int nComponents, LldaDml.SolverType solver)
ML.dml.kda()   ML.dml.kda(KernelType kernel, double gamma, int nComponents)
ML.dml.fisherWhitening()  ML.dml.fisherWhitening(double l2Weight)
ML.dml.rca()   ML.dml.rca(double l2Weight)
ML.dml.withinClass()  ML.dml.withinClass(double l2Weight)
ML.dml.odml()  ML.dml.odml(double lr, double aggression)
ML.dml.ncmc()  ML.dml.ncmc(int centroidsNum, int maxIter)
ML.dml.ncmml()  ML.dml.ncmml(Integer numDims, int maxIter)
ML.dml.cnn()   ML.dml.rnn()
ML.dml.multiDmlKnn(ISupervisedDml... dmls)
```

### Kernelized DML

```java
ML.dml.kllda(KernelType kernel, double gamma, int nComponents)
ML.dml.kanmm(KernelType kernel, double gamma, int k)
ML.dml.kdmlmj(KernelType kernel, double gamma)
ML.dml.klmnn(KernelType kernel, double gamma, int rank, double margin)
ML.dml.kodml(KernelType kernel, double gamma, double lr)
```

### Unsupervised DML

```java
ML.dml.lsi()   → IUnsupervisedDml
ML.dml.lsi(int nComponents, int nNeighbors) → IUnsupervisedDml
ML.dml.lsiMmc()   ML.dml.lsiMmc(int maxIter, double tol)
```

### ISupervisedDml Interface

```java
dml.fit(IMatrix<Double> features, String[] labels) → ISupervisedDml
dml.transform(IMatrix data) → IMatrix<Double>
dml.transformMatrix()       → IMatrix<Double>  // learned metric matrix
```

---

## ML.preproc — Preprocessing

### Scalers (support inverseTransform)

```java
ML.preproc.standardScaler()                      → IRereScaler<Double>
ML.preproc.standardScaler(boolean withStd)       → IRereScaler<Double>
ML.preproc.minMaxScaler()                        → IRereScaler<Double>
ML.preproc.minMaxScaler(double min, double max)  → IRereScaler<Double>
ML.preproc.robustScaler()                        → IRereScaler<Double>
ML.preproc.maxAbsScaler()                        → IRereScaler<Double>
```

### Transformers (no inverse)

```java
ML.preproc.normalizer()                          → ITransform<Double>
ML.preproc.normalizer(Norm norm)                 → ITransform<Double>
ML.preproc.polynomialFeatures()                  → ITransform<Double>
ML.preproc.polynomialFeatures(int degree)        → ITransform<Double>
ML.preproc.polynomialFeatures(int degree, boolean includeBias, boolean interactionOnly)
ML.preproc.binarizer()                           → ITransform<Double>
ML.preproc.binarizer(double threshold)           → ITransform<Double>
ML.preproc.oneHotEncoder()                       → ITransform<Double>
ML.preproc.labelBinarizer()                      → ITransform<Double>
ML.preproc.powerTransformer()                    → ITransform<Double>
ML.preproc.powerTransformer(Method method)       → ITransform<Double>
ML.preproc.quantileTransformer()                 → ITransform<Double>
ML.preproc.quantileTransformer(int nQuantiles)   → ITransform<Double>
ML.preproc.quantileTransformer(OutputDistribution dist) → ITransform<Double>
ML.preproc.kernelCenterer()                      → ITransform<Double>
ML.preproc.bucketizer()                          → ITransform<Double>
ML.preproc.bucketizer(int nBins)                 → ITransform<Double>
ML.preproc.bucketizer(Strategy strategy, int nBins) → ITransform<Double>
```

### IRereScaler adds:

```java
scaler.inverseTransform(IMatrix scaled) → IMatrix<Double>
```
