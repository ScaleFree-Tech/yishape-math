# Opts — Optimization Reference

**Import:** `com.yishape.lab.math.optimize.Opts`

## Sub-facade Fields

```java
Opts.mclp    // MclpWrapper — Multi-Criteria LP (static methods)
Opts.mcqp    // McqpWrapper — Multi-Criteria QP (static methods)
```

---

## Unconstrained Optimizers

```java
Opts.lbfgs()                                                → IOptimizer
Opts.lbfgs(double tolerance, int maxSteps)                  → IOptimizer
Opts.lbfgs(LBFGSType type)                                  → IOptimizer  // STANDARD, OWL_QN
Opts.lbfgs(double tol, int maxSteps, LBFGSType type)        → IOptimizer
Opts.owlqn()                                                → IOptimizer  // L1-regularized
Opts.conjugateGradient()                                    → IOptimizer
Opts.dfp()                                                  → IOptimizer
Opts.steepestDescent()                                      → IOptimizer

// IOptimizer config (fluent)
optimizer.setMaxIterations(int n)     → IOptimizer
optimizer.setTolerance(double tol)    → IOptimizer
optimizer.setM(int m)                 → IOptimizer  // L-BFGS history size

// IOptimizer.optimize
optimizer.optimize(IVector initX, IObjectiveFunction objFun, IGradientFunction grdFun) → OptResult
// OptResult: getOptimalPoint(), getOptimalValue(), getIterationCount(), isConverged()
```

## Online Optimizers

```java
Opts.onlineAdam()                                           → IOnlineOptimizer
Opts.onlineAdam(double lr, double beta1, double beta2)     → IOnlineOptimizer
Opts.onlineSGD()                                            → IOnlineOptimizer

// IOnlineOptimizer
opt.initialize(IVector initialParams)
opt.step(IVector gradient)                    → IVector
opt.step(IVector gradient, double loss)       → IVector
opt.getCurrentParams()                        → IVector
opt.getCurrentLearningRate()                  → double
opt.getCurrentStep()                          → int
opt.reset()   opt.isInitialized()             → boolean
opt.setLearningRate(double lr)   opt.setLrDecayRate(double rate)   opt.setLrDecayStep(int step)
```

## Linear Programming

**IMPORTANT:** Solvers minimize by default. Negate `c` for maximization.

```java
Opts.simplexLinProgSolver()       → ILinProgSolver
Opts.interPointLinProgSolver()    → ILinProgSolver
Opts.linProgSolver()              → ILinProgSolver   // auto-selects best
Opts.linProgSolver(LpSolverType)  → ILinProgSolver
Opts.intLinProgSolver()           → IIntegerProg

// ILinProgSolver.solve — minimize cᵀx subject to constraints
solver.solve(IVector c, IMatrix A_ub, IVector b_ub)                              // A_ub·x ≤ b_ub
solver.solve(IVector c, IMatrix A_ub, IVector b_ub, IMatrix A_eq, IVector b_eq)  // + A_eq·x = b_eq
solver.solveEq(IVector c, IMatrix A_eq, IVector b_eq)                            // equality only, x ≥ 0
// Result: getOptimalValue(), getOptimalPoint(), isOptimal()

// IIntegerProg extends ILinProgSolver
ip.addIntegerVariables(int... indices)
ip.setAllVariablesInteger()
ip.setAllVariablesBinary()
ip.setBinaryVariable(int index)
ip.setMaxDepth(int depth)
ip.setGapTolerance(double tol)
ip.setVerbose(boolean v)
```

## Multi-Criteria LP (Opts.mclp — static methods)

```java
Opts.mclp.weightedSumMclp(double[] weights)       → IMclpSolver
Opts.mclp.lexicographicMclp(int[] priorityOrder)  → IMclpSolver
Opts.mclp.goalProgrammingMclp(double[] goals, double[] weights) → IMclpSolver
Opts.mclp.paretoMclp(int numSamples)              → IMclpSolver
Opts.mclp.ahpMclp(IMatrix comparisonMatrix)       → IMclpSolver  // Saaty 1-9 scale
Opts.mclp.topsisMclp(double[] weights)            → IMclpSolver
Opts.mclp.interactiveMclp(DecisionMakerCallback)  → IMclpSolver
Opts.mclp.mclp(MclpSolverType type)               → IMclpSolver

// IMclpSolver.solve(IVector[] c, IMatrix A_ub, IVector b_ub,
//                   IMatrix A_eq, IVector b_eq, IVector initX) → MclpResult
// MclpResult: getSelectedSolution(), getSelectedObjectiveValues(),
//   getSolutions(), getObjectiveValues(), isParetoOptimal(i),
//   getSummary(), getDetailedReport(), getIdealPoint(), getNadirPoint()
```

## Multi-Criteria QP (Opts.mcqp — static methods)

```java
Opts.mcqp.weightedSumQp(double[] weights)               → IMcqpSolver
Opts.mcqp.lexicographicQp(int[] priorityOrder)           → IMcqpSolver
Opts.mcqp.goalProgrammingQp(double[] goals, double[] w)  → IMcqpSolver
Opts.mcqp.paretoQp(int numSamples)                       → IMcqpSolver
Opts.mcqp.ahpQp(IMatrix comparisonMatrix)                → IMcqpSolver
Opts.mcqp.topsisQp(double[] weights)                     → IMcqpSolver
Opts.mcqp.interactiveQp(int maxIterations)               → IMcqpSolver

// Quick bi-objective:
Opts.mcqp.solveBiObjective(IMatrix Q1, IVector c1, IMatrix Q2, IVector c2,
    IMatrix A_ub, IVector b_ub, double weight)           → McqpResult
```

## Line Search

```java
var ls = new RereLineSearch(double c1, double c2, double initialStepSize);
ls.search(IVector point, IVector direction,
    IObjectiveFunction objFun, IGradientFunction grdFun, IVector gradient) → LineSearchResult
```

## Constrained Optimization

```java
// com.yishape.lab.math.optimize.constraint.LagrangeMultiplierSolver
var solver = new LagrangeMultiplierSolver(IMatrix A_eq, IVector b_eq);
solver.setPenaltyFactor(double f);
solver.setMaxPenaltyIterations(int n);
solver.setPenaltyIncreaseRate(double rate);
solver.optimize(IVector initX, IObjectiveFunction objFun, IGradientFunction grdFun) → OptResult
```
