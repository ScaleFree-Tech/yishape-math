# Plots — Visualization Reference

**Import:** `com.yishape.lab.math.plot.Plots`

## Backend Selection & Factory

```java
// Auto-select backend
Plots.of()                       → IPlot
Plots.of(int width, int height)  → IPlot
Plots.of(int w, int h, String theme) → IPlot
Plots.of(PlotProvider provider)  → IPlot

// Explicit backends
Plots.ofJavaFx()                 → IPlot
Plots.ofJavaFx(int w, int h)    → IPlot
Plots.ofEcharts()                → IPlot
Plots.ofEcharts(int w, int h)   → IPlot
Plots.ofSvg()                    → SvgPlot
Plots.ofSvg(int w, int h)       → SvgPlot
Plots.svg(int w, int h)         → SvgPlot

// 3D
Plots.of3d()                     → I3dPlot
Plots.of3d(int w, int h)        → I3dPlot
Plots.of3d(int w, int h, String theme) → I3dPlot

// Provider switching
Plots.setProvider(PlotProvider provider)        // JAVAFX, ECHARTS, SVG
Plots.setProvider3d(PlotProvider3d provider3d)  // JAVAFX, ECHARTSGL
```

---

## 2D Chart Types (IPlot — all fluent, return IPlot)

### Cartesian
```java
.line(IVector y)                       // auto x = 0,1,2,...
.line(IVector x, IVector y)
.line(x, y, String styleExpr)          // "r-", "b--o", "ko", "C0-"
.line(x, y, PlotStyle style)
.line(x, y, List<String> hue)          // grouped by category
.line(x, y, List<String> hue, List<String> styleGroup)

.scatter(IVector x, IVector y)
.scatter(x, y, String styleExpr)
.scatter(x, y, PlotStyle style)
.scatter(x, y, List<String> hue)       // grouped scatter
.scatter(x, y, IVector sizes)          // bubble scatter
```

### Bar
```java
.bar(IVector data)
.bar(IVector data, List<String> hue)                    // grouped bar
.bar(List<String> xticks, IVector y)                    // categorical x
.bar(List<String> xticks, IVector y, List<String> hue)
.barh(List<String> categories, IVector values)          // horizontal
.barStacked(List<String> categories, IMatrix values, List<String> layerNames)
```

### Distribution
```java
.hist(IVector data, boolean fittingLine)
.hist(data, fittingLine, PlotStyle style, Integer bins)
.boxplot(IVector data)
.boxplot(IVector data, List<String> labels)
.boxplot(IVector data, List<String> labels, PlotStyle style)
.violinplot(IVector data)
.violinplot(IVector data, List<String> labels)
.violinplot(IVector data, List<String> labels, PlotStyle style)
.kdeplot(IVector data)
.kdeplot(IVector data, int gridPoints, double bandwidth)
```

### Pie
```java
.pie(IVector data)
.pie(IVector data, List<String> labels)
.pie(IVector data, List<String> labels, String styleExpr)
.pie(IVector data, List<String> labels, PlotStyle style)
```

### Polar
```java
.polarBar(IVector data, List<String> categories)
.polarLine(IVector data, List<String> categories)
.polarScatter(IVector data, List<String> categories)
// Each supports String styleExpr or PlotStyle overloads
```

### Financial
```java
.candlestick(IMatrix ohlc, List<String> dates)   // columns: Open, High, Low, Close
.candlestick(IMatrix ohlc, List<String> dates, PlotStyle style)
.gauge(double value, double max, double min)
.gauge(double value, double max, double min, PlotStyle style)
```

### Statistical / Seaborn-style
```java
.regplot(IVector x, IVector y)                        // regression line + scatter
.regplot(x, y, boolean confidenceBand)
.qqplot(IVector data)                                 // Q-Q plot
.pairplot(IMatrix data)                               // scatter matrix
.pairplot(IMatrix data, List<String> colNames, PairplotDiagonal diagonal)
.jointplot(IVector x, IVector y, JointplotMarginal marginal) // scatter + marginals
.errorbar(IVector x, IVector y, IVector yerr)
.area(IVector x, IVector y)                           // filled area
.step(IVector x, IVector y)                           // step line
.lineWithSecondaryY(IVector x, IVector yLeft, IVector yRight)
```

### Advanced
```java
.heatmap(IMatrix data)
.heatmap(IMatrix data, List<String> xLabels, List<String> yLabels)
.heatmap(IMatrix data, List<String> xLabels, List<String> yLabels, PlotStyle style)
.radar(IVector data, List<String> indicators)
.radar(IVector data, List<String> indicators, PlotStyle style)
.funnel(IVector data, List<String> labels)
.funnel(IVector data, List<String> labels, PlotStyle style)
```

### Graph / Hierarchical (use List<Map<String, Object>> for nodes/links)
```java
.sankey(List<Map> nodes, List<Map> links)
.sunburst(List<Map> data)
.tree(List<Map> data)
.treemap(List<Map> data)
.graph(List<Map> nodes, List<Map> links)
.parallel(IMatrix data, List<String> dimensions)
.themeRiver(List<Map> data, List<String> categories)
```

---

## 3D Chart Types (I3dPlot)

```java
.scatter3d(IVector x, IVector y, IVector z)
.scatter3d(x, y, z, List<String> hueGroup)         // grouped 3D scatter
.scatterBubble3d(x, y, z, IVector sizes)            // bubble 3D
.line3d(x, y, z)
.surface3d(IVector x, IVector y, IMatrix z)         // surface
.surface3d(x, y, z, boolean showContour)            // surface + contour projection
.contour3d(x, y, z)                                 // contour only
.wireframe3d(x, y, z)
.bar3d(List<String> categories, IMatrix values, BarExtrusion3D extrusion)
// BarExtrusion3D: BOX, CYLINDER, CONE
.hist3d(IVector x, IVector y, int xBins, int yBins)
.vectorField3d(IVector x, IVector y, IVector z, IVector u, IVector v, IVector w)
.streamlines3d(x, y, z, u, v, w)
.graph3d(List<Map> nodes, List<Map> links)
.terrain3d(IVector x, IVector y, IMatrix z)
.radar3d(IVector data, List<String> indicators)
```

---

## Fluent Config & Output

```java
.title(String title)                     .title(String title, String subtitle)
.xlabel(String label)                    .ylabel(String label)    .zlabel(String) // 3D
.xscale(PlotAxisScale scale)             .yscale(PlotAxisScale scale)
.y2label(String label)                   // for dual-Y charts
.size(int width, int height)
.theme(String themeName)                 // built-in: "dark", "light", etc.
.legend()                                .legend(boolean show)
.setPalette(String paletteName)          // "matplotlib", etc.
.subplots(int rows, int cols)            // facet grid

// Output
.show()                                  // interactive display
.saveAsHtml(String path)                 .saveAsSvg(String path)
.saveAsPng(String path)                  .saveAsPdf(String path)
.toHtml() → String                       .toBase64Svg() → String     .toBase64Png() → String
```

---

## Style System

### Style Expressions (matplotlib-inspired)
```
"r-"      red solid line          "b--o"    blue dashed + circle markers
"ko"      black circle only       "g:s"     green dotted + square markers
"#FF5733-s"  hex + square         "C0-"     palette color 0, solid
```

### PlotStyle Object
```java
PlotStyle style = new PlotStyle()
    .color("#3498DB")
    .lineStyle(LineStyle.SOLID)     // SOLID, DASHED, DOTTED, DASHDOT
    .lineWidth(2.5)
    .marker(Marker.CIRCLE)          // CIRCLE, SQUARE, DIAMOND, TRIANGLE, CROSS, etc.
    .markerSize(8)
    .alpha(0.8)
    .label("Series A")
    .emphasis(new PlotStyle().color("#E74C3C").lineWidth(4.0))  // hover state
    .blur(new PlotStyle().alpha(0.3));                          // non-focused state
```

### Theme Management
```java
Plots.of(800, 600, "dark")          // apply theme at creation
.applyTheme(String themeName)
.enableThemeSystem(boolean)
.registerTheme(String name, EchartsThemeManager.CustomTheme theme)
.createGradientTheme(String name, String startColor, String endColor, String bgColor)
.createMonochromeTheme(String name, String baseColor, String bgColor)
.listThemes() → List<String>
```
