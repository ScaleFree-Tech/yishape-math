# Signals — Signal Processing Reference

**Import:** `com.yishape.lab.math.signal.Signals`

## Sub-facade Fields

```java
Signals.gen       // GenWrapper — signal generation
Signals.filt      // FiltWrapper — filtering
Signals.xform     // XformWrapper — transforms
Signals.analyze   // AnalyzeWrapper — spectral analysis
Signals.plot      // PlotWrapper — visualization (delegates to Plots)
```

---

## Signals.gen — Signal Generation

```java
// Basic waveforms
Signals.gen.sineWave(int len, double freq, double fs, double amp, double phase) → IVector<Double>
Signals.gen.cosineWave(int len, double freq, double fs, double amp, double phase) → IVector<Double>
Signals.gen.squareWave(int len, double freq, double fs, double amp, double dutyCycle) → IVector<Double>
Signals.gen.triangularWave(int len, double freq, double fs, double amp, double symmetry) → IVector<Double>
Signals.gen.sawtoothWave(int len, double freq, double fs, double amp) → IVector<Double>

// Noise
Signals.gen.whiteNoise(int length, double power) → IVector<Double>
Signals.gen.pinkNoise(int length, double power) → IVector<Double>

// Special
Signals.gen.chirpSignal(int len, double startFreq, double endFreq, double fs, double amp) → IVector<Double>
Signals.gen.stepSignal(int len, double amp, double stepTime, double fs) → IVector<Double>
Signals.gen.unitStep(int len, double stepTime, double fs) → IVector<Double>
Signals.gen.unitImpulse(int len, int impulseIndex) → IVector<Double>
Signals.gen.diracDelta(int len, int impulseIndex, double amp) → IVector<Double>
Signals.gen.pulseSignal(int len, double amp, int pulseWidth, double freq, double fs) → IVector<Double>

// Composite & noise addition
Signals.gen.compositeSignal(SignalType[] types, int len, SignalParameters[] params) → IVector<Double>
Signals.gen.addNoise(IVector<Double> signal, SignalType noiseType, SignalParameters params) → IVector<Double>
```

---

## Signals.filt — Filtering

```java
Signals.filt.movingAverage(IVector<Double> signal, int windowSize) → IVector<Double>
Signals.filt.medianFilter(IVector<Double> signal, int windowSize) → IVector<Double>
Signals.filt.gaussianFilter(IVector<Double> signal, double sigma) → IVector<Double>
Signals.filt.gaussianFilter(IVector<Double> signal, double sigma, int kernelSize) → IVector<Double>

// Butterworth family
Signals.filt.butterworthLowPass(IVector<Double> signal, double cutoff, double fs, int order) → IVector<Double>
Signals.filt.butterworthHighPass(IVector<Double> signal, double cutoff, double fs, int order) → IVector<Double>
Signals.filt.bandPass(IVector<Double> signal, double low, double high, double fs, int order) → IVector<Double>
Signals.filt.bandStop(IVector<Double> signal, double low, double high, double fs, int order) → IVector<Double>

// Advanced
Signals.filt.kalmanFilter(IVector<Double> signal, double processNoiseVar, double measurementNoiseVar) → IVector<Double>
Signals.filt.wienerFilter(IVector<Double> signal, double signalPower, double noisePower, int filterLen) → IVector<Double>
```

---

## Signals.xform — Transforms

```java
// FFT family
Signals.xform.fft(Complex[] x) → Complex[]
Signals.xform.ifft(Complex[] x) → Complex[]
Signals.xform.magnitudeSpectrum(Complex[] fftResult) → double[]
Signals.xform.phaseSpectrum(Complex[] fftResult) → double[]
Signals.xform.powerSpectrum(Complex[] fftResult) → double[]

// DCT
Signals.xform.dct2(IVector<Double> signal) → IVector<Double>
Signals.xform.idct2(IVector<Double> dctSignal) → IVector<Double>

// Hilbert
Signals.xform.hilbertTransform(IVector<Double> signal) → IVector<Double>
Signals.xform.analyticSignal(IVector<Double> signal) → Complex[]
Signals.xform.instantaneousAmplitude(IVector<Double> signal) → IVector<Double>
Signals.xform.instantaneousPhase(IVector<Double> signal) → IVector<Double>
Signals.xform.instantaneousFrequency(IVector<Double> signal, double fs) → IVector<Double>

// Wavelet
Signals.xform.discreteWaveletTransform(IVector<Double> signal,
    WaveletType type, int levels, double param) → WaveletCoefficients
Signals.xform.inverseDiscreteWaveletTransform(WaveletCoefficients coeffs,
    WaveletType type, double param) → IVector<Double>
// WaveletType: HAAR, DAUBECHIES, MORLET, etc.
```

---

## Signals.analyze — Analysis

```java
Signals.analyze.powerSpectralDensity(IVector<Double> signal,
    int windowSize, double overlap, double fs) → Tuple2<IVector, IVector>

Signals.analyze.autocorrelation(IVector<Double> signal) → IVector<Double>
Signals.analyze.crossCorrelation(IVector<Double> s1, IVector<Double> s2) → IVector<Double>
Signals.analyze.crossCorrelation(IVector<Double> s1, IVector<Double> s2, int maxLag) → IVector<Double>

Signals.analyze.spectrum(IVector<Double> signal, double fs)
    → Tuple3<IVector, IVector, IVector>  // (freqs, magnitudes, phases)

Signals.analyze.shortTimeFourierTransform(IVector<Double> signal,
    int windowSize, int hopSize, double fs) → IMatrix<Double>

Signals.analyze.signalToNoiseRatio(IVector<Double> signal, IVector<Double> noise) → double
Signals.analyze.peakSignalToNoiseRatio(IVector<Double> original, IVector<Double> reconstructed) → double
```
