# Stats — Statistics Reference

**Import:** `com.yishape.lab.math.stats.Stats`

## Sub-facade Fields

```java
Stats.estimator   // ParameterEstimation — confidence intervals
Stats.tester      // HypothesisTesting — t-tests, chi2, F-tests
Stats.anova       // ANOVA — oneWay, twoWay, repeatedMeasures
```

## Continuous Distributions (static factories)

```java
Stats.norm(double mean, double stdDev)      → NormalDistribution
Stats.norm()                                → NormalDistribution (0,1)
Stats.t(double dof)                         → StudentDistribution
Stats.t(double dof, double loc, double scale)
Stats.chi2(double dof)                      → Chi2Distribution
Stats.f(double dof1, double dof2)           → FDistribution
Stats.uniform(double lower, double upper)   → UniformDistribution
Stats.exponential(double rate)              → ExponentialDistribution
Stats.beta(double alpha, double beta)       → BetaDistribution
Stats.gamma(double alpha, double beta)      → GammaDistribution
```

## Discrete Distributions (static factories)

```java
Stats.bernoulli(double p)                   → BernoulliDistribution
Stats.binomial(int n, double p)             → BinomialDistribution
Stats.poisson(double lambda)                → PoissonDistribution
Stats.geometric(double p)                   → GeometricDistribution
Stats.negativeBinomial(int r, double p)     → NegativeBinomialDistribution
Stats.discreteUniform(int a, int b)         → DiscreteUniformDistribution
Stats.discreteUniform(int n)                → DiscreteUniformDistribution [0,n]
```

## Distribution Methods

```java
// --- Continuous ---
dist.pdf(double x)     → double    // probability density
dist.cdf(double x)     → double    // cumulative distribution
dist.ppf(double p)     → double    // quantile (inverse CDF)
dist.sf(double x)      → double    // survival = 1 - CDF
dist.isf(double p)     → double    // inverse survival
dist.mean()  dist.var()  dist.std()  dist.median()  dist.mode()
dist.skewness()  dist.kurtosis()  dist.q1()  dist.q3()
dist.sample()           → double
dist.sample(int n)      → double[]

// --- Discrete ---
dist.pmf(int x)         → double
dist.cdf(int x)         → double
dist.ppf(double p)      → int
dist.sf(int x)          → double
dist.isf(double p)      → int
dist.sample()           → int
dist.sample(int n)      → int[]
dist.moment(int k)      → double
dist.centralMoment(int k) → double
dist.standardizedMoment(int k) → double
dist.entropy()          → double
dist.klDivergence(IDiscreteDistribution other) → double
dist.jsDivergence(IDiscreteDistribution other) → double
dist.wassersteinDistance(IDiscreteDistribution other) → double
dist.getMinSupport() dist.getMaxSupport() dist.isInSupport(int x)
dist.isBounded() dist.isSymmetric() dist.isMemoryless()
dist.confidenceInterval(double level) → Tuple2<Integer, Integer>
```

## Hypothesis Testing & Parameter Estimation

```java
// Parameter estimation (returns interval Tuple2)
Stats.estimator.estimateMeanIntevalWithT(IVector sample, double confidence)
Stats.estimator.estimateVarIntevalWithChi2(IVector sample, double confidence)

// Hypothesis testing (returns TestingResult)
// TestingResult: .pass (boolean), .p (double), .criticalInteval (Tuple2)
Stats.tester.testMeanEqualWithT(double hypothesizedMean, IVector sample, double confidence)
Stats.tester.testVarEqualWithChi2(double hypothesizedVar, IVector sample, double confidence)
```

## ANOVA

```java
Stats.anova.performOneWayANOVA(IVector... groups)              → ANOVAResult
Stats.anova.performTwoWayANOVA(...)                            → TwoWayANOVAResult
Stats.anova.performRepeatedMeasuresANOVA(...)                  → RepeatedMeasuresANOVAResult
```

## Correlation & Covariance

```java
Stats.corr(IVector<T> x1, IVector<T> x2)  → double   // Pearson
Stats.cov(IVector<T> x1, IVector<T> x2)   → double
```

## Multivariate Distributions

Package: `com.yishape.lab.math.stats.distribution.multiv.MultivariateDistributions`

```java
MultivariateDistributions.normal(IVector mean, IMatrix covariance)     → IMultivariateDistribution
MultivariateDistributions.t(double dof, IVector mean, IMatrix scale)   → IMultivariateDistribution
MultivariateDistributions.uniform(IVector lower, IVector upper)        → IMultivariateDistribution
// Also: beta, exponential, Dirichlet, Wishart, InverseWishart

// IMultivariateDistribution methods:
dist.pdf(IVector x)   dist.logPdf(IVector x)   dist.sample() → IVector
dist.sample(int n) → List<IVector>   dist.sampleMatrix(int n) → IMatrix
dist.getMean() → IVector   dist.getCovariance() → IMatrix
dist.getCorrelation() → IMatrix   dist.getPrecision() → IMatrix
dist.mahalanobisDistance(IVector x)   dist.squaredMahalanobisDistance(IVector x)
dist.getMarginal(int... dims)   dist.getConditional(int[] condDims, IVector values)
dist.linearTransform(IMatrix A, IVector b)   dist.affineTransform(IMatrix A)
dist.klDivergence(dist2)   dist.wassersteinDistance(dist2)
dist.entropy()   dist.informationMatrix()
dist.getConfidenceEllipse(double level) → ConfidenceEllipse
```

## Gaussian Mixture Models

Package: `com.yishape.lab.math.stats.model`

```java
var gmm = new GaussianMixtureModel(int nComponents, int dimensions);
gmm.fit(IMatrix data);
gmm.predictComponent(IVector x) → int
gmm.computePosteriors(IVector x) → IVector<Double>
gmm.pdf(IVector x) → double
gmm.sample() → IVector

var em = new EMAlgorithm(gmm);
em.fit(IMatrix data, double tolerance, int maxIterations);
```
