# TSA — Time Series Analysis Reference

**Import:** `com.yishape.lab.math.timeseries.TSA`

## Static Factory

```java
TSA.data(IVector<Double> values, String name) → TimeSeriesData
TSA.data(double[] values, String name) → TimeSeriesData
TSA.data(IVector<Double> values, String name, LocalDateTime[] timestamps) → TimeSeriesData
```

## Sub-facade Fields

```java
TSA.forecast     // ForecastWrapper
TSA.filter       // FilterWrapper
TSA.decompose    // DecomposeWrapper
TSA.cointegrate  // CointegrateWrapper
TSA.plot         // PlotWrapper
```

---

## TSA.forecast — Forecasting

```java
// All return ForecastResult:
//   .getForecast(), .getForecastVector(), .getLowerBounds(), .getUpperBounds()
//   .getMSE(), .getMAE(), .getMAPE(), .getConfidenceLevel(), .getSummary()

TSA.forecast.movingAverage(IVector<Double> data, int windowSize, int steps)
TSA.forecast.movingAverage(IVector<Double> data, int windowSize, int steps, double confidence)

TSA.forecast.expSmooth(IVector<Double> data, double alpha, int steps)
TSA.forecast.expSmooth(IVector<Double> data, double alpha, int steps, double confidence)

TSA.forecast.linearTrend(IVector<Double> data, int steps)
TSA.forecast.linearTrend(IVector<Double> data, int steps, double confidence)

TSA.forecast.arima(IVector<Double> data, int p, int d, int q, int steps)
TSA.forecast.arima(IVector<Double> data, int p, int d, int q, int steps, double confidence)

TSA.forecast.seasonal(IVector<Double> data, int period, int steps)
TSA.forecast.seasonal(IVector<Double> data, int period, int steps, double confidence)

TSA.forecast.holtWinters(IVector<Double> data, double alpha, double beta, double gamma,
    int period, int steps)
TSA.forecast.holtWinters(IVector<Double> data, double alpha, double beta, double gamma,
    int period, int steps, double confidence)

TSA.forecast.garch(IVector<Double> data, int p, int q, int steps)
TSA.forecast.garch(IVector<Double> data, int p, int q, int steps, double confidence)

TSA.forecast.stateSpace(IVector<Double> data, double sigmaEta, double sigmaZeta,
    double sigmaEpsilon, int steps)
TSA.forecast.stateSpace(IVector<Double> data, double sigmaEta, double sigmaZeta,
    double sigmaEpsilon, int steps, double confidence)

TSA.forecast.auto(IVector<Double> data, int steps)  // automatic model selection
TSA.forecast.auto(IVector<Double> data, int steps, double confidence)
```

---

## TSA.filter — Filtering

```java
// All return FilterResult: .getFiltered(), .getFilterType(), .getSNR()

TSA.filter.movingAverage(IVector<Double> data, int windowSize)
TSA.filter.expSmooth(IVector<Double> data, double alpha)
TSA.filter.gaussian(IVector<Double> data, double sigma)
TSA.filter.median(IVector<Double> data, int windowSize)
TSA.filter.lowPass(IVector<Double> data, double cutoffFreq, int order)
TSA.filter.lowPass(IVector<Double> data, double cutoffFreq, double samplingRate, int order)
TSA.filter.highPass(IVector<Double> data, double cutoffFreq, int order)
TSA.filter.highPass(IVector<Double> data, double cutoffFreq, double samplingRate, int order)
TSA.filter.bandPass(IVector<Double> data, double lowFreq, double highFreq, int order)
TSA.filter.bandPass(IVector<Double> data, double lowFreq, double highFreq, double fs, int order)
TSA.filter.adaptive(IVector<Double> data, double learningRate)
```

---

## TSA.decompose — Decomposition

```java
// All return DecompositionResult:
//   .getTrend(), .getSeasonal(), .getResidual()
//   .getTrendStrength(), .getSeasonalStrength(), .getResidualStrength()
//   .getPeriod()

TSA.decompose.classical(IVector<Double> data, int period,
    TimeSeriesDecomposition.DecompositionModel type)  // ADDITIVE or MULTIPLICATIVE

TSA.decompose.x13(IVector<Double> data, int period)

TSA.decompose.stl(IVector<Double> data, int period,
    int seasonalWindow, int trendWindow)

TSA.decompose.wavelet(IVector<Double> data, String waveletType, int levels)
```

---

## TSA.cointegrate — Cointegration

```java
TSA.cointegrate.engleGrangerTest(IVector<Double> y, IVector<Double> x, int maxLags)
    → CointegrationAnalysis.EngleGrangerResult

TSA.cointegrate.johansenTest(IMatrix<Double> data, int maxLags,
    CointegrationAnalysis.TrendType trendType)
    → CointegrationAnalysis.JohansenResult

TSA.cointegrate.estimateCointegratingRelationship(IVector<Double> y, IVector<Double> x)
    → CointegrationAnalysis.CointegratingRelationship

TSA.cointegrate.estimateECM(IVector<Double> deltaY, IVector<Double> deltaX,
    IVector<Double> residuals, int maxLags)
    → CointegrationAnalysis.ErrorCorrectionModel
```
