# VI — Vector Indexing (ANN) Reference

**Import:** `com.yishape.lab.math.vecidx.VI`

## Distance Metrics

```java
new EuclideanMetric()          // L2 distance
new CosineMetric()             // cosine similarity
new InnerProductMetric()       // inner product (negative for distance)
new ManhattanMetric()          // L1 distance
new SquaredEuclideanMetric()   // squared L2
// DML adapter:
new DmlMetricAdapter(ISupervisedDml learnedMetric)
```

## VecSearchOption (configuration builder)

```java
var opts = new VecSearchOption();
// Common settings:
//   .setEfConstruction(int)    — HNSW construction ef (default ~200)
//   .setEfSearch(int)          — HNSW search ef (default ~100)
//   .setM(int)                 — HNSW M (connections per layer, default 16)
//   .setNumTrees(int)          — LSH/KD-Tree hash tables or trees
//   .setNumSubspaces(int)      — PQ subspaces
//   .setNumCentroids(int)      — PQ centroids per subspace
//   .setNumBits(int)           — LSH bits per table
//   .setMaxIter(int)           — OPQ/learning iterations
//   .setNumProbes(int)         — search probes for LSH/PQ
```

## Index Builders

### Auto-select (best index type chosen automatically)

```java
VI.buildDouble(double[][] data, String[] ids, VecSearchOption options) → IDoubleVecIdx
VI.buildDouble(double[][] data, String[] ids, IDisMetric<Double> metric,
    VecSearchOption options) → IDoubleVecIdx
VI.buildFloat(float[][] data, String[] ids, VecSearchOption options) → IFloatVecIdx
VI.buildFloat(float[][] data, String[] ids, IDisMetric<Float> metric,
    VecSearchOption options) → IFloatVecIdx

// Build from subset of full matrix (for ID mapping scenarios)
VI.buildDoubleSubset(double[][] fullMatrix, String[] subsetIds,
    IDisMetric<Double> metric, VecSearchOption options) → IDoubleVecIdx
VI.buildFloatSubset(float[][] fullMatrix, String[] subsetIds,
    IDisMetric<Float> metric, VecSearchOption options) → IFloatVecIdx

// From IMatrix
VI.build(IMatrix<T> data, String[] ids, IDisMetric<T> metric,
    VecSearchOption options) → IVecIdx<T>
```

### Specific Index Types

```java
// LSH (Locality-Sensitive Hashing)
VI.buildLshDouble(double[][] data, String[] ids,
    IDisMetric<Double> metric, VecSearchOption options) → IDoubleVecIdx
VI.buildLshFloat(float[][] data, String[] ids,
    IDisMetric<Float> metric, VecSearchOption options) → IFloatVecIdx

// Product Quantization
VI.buildPqDouble(double[][] data, String[] ids,
    IDisMetric<Double> metric, VecSearchOption options) → IDoubleVecIdx
VI.buildPqFloat(float[][] data, String[] ids,
    IDisMetric<Float> metric, VecSearchOption options) → IFloatVecIdx

// Optimized Product Quantization
VI.buildOpqDouble(double[][] data, String[] ids,
    IDisMetric<Double> metric, VecSearchOption options) → IDoubleVecIdx
VI.buildOpqFloat(float[][] data, String[] ids,
    IDisMetric<Float> metric, VecSearchOption options) → IFloatVecIdx

// PQ + HNSW (quantization for compression + graph for search)
VI.buildPqHnswDouble(double[][] data, String[] ids,
    IDisMetric<Double> metric, VecSearchOption options) → IDoubleVecIdx
VI.buildPqHnswFloat(float[][] data, String[] ids,
    IDisMetric<Float> metric, VecSearchOption options) → IFloatVecIdx

// OPQ + HNSW
VI.buildOpqHnswDouble(double[][] data, String[] ids,
    IDisMetric<Double> metric, VecSearchOption options) → IDoubleVecIdx
VI.buildOpqHnswFloat(float[][] data, String[] ids,
    IDisMetric<Float> metric, VecSearchOption options) → IFloatVecIdx
```

### Learning LSH (semi-supervised — uses similar/dissimilar pairs)

```java
VI.buildLearningLshDouble(double[][] data, String[] ids,
    IDisMetric<Double> metric, VecSearchOption options,
    List<LearningLshDoubleVecIdx.SimilarPair> similarPairs) → IDoubleVecIdx

VI.buildLearningLshDouble(double[][] data, String[] ids,
    IDisMetric<Double> metric, VecSearchOption options,
    List<SimilarPair> similarPairs,
    OptimizeMode optimizeMode, OptimizerType optimizerType,
    double learningRate, int epochs, double l2Regularization,
    int batchSize, double epsilon, double stopThreshold, long seed) → IDoubleVecIdx

VI.buildLearningLshFloat(...)  // same overloads for float
```

### Mutable Index (add/remove vectors dynamically, BruteForce backend)

```java
VI.newMutableDouble(int dimensions, IDisMetric<Double> metric,
    VecSearchOption options) → IMutableVecIdx<Double>
VI.newMutableFloat(int dimensions, IDisMetric<Float> metric,
    VecSearchOption options) → IMutableVecIdx<Float>
```

---

## IVecIdx<T> Interface

```java
idx.dimensions() → int
idx.size() → int
idx.metric() → IDisMetric<T>
idx.isApproximate() → boolean

// --- Search ---
idx.search(IVector<T> query, int k) → List<SearchHit>
idx.search(query, k, Set<String> excludeIds, Predicate<String> filter) → List<SearchHit>
idx.search(query, k, IDisMetric<T> refineMetric, int ef) → List<SearchHit> // two-stage
idx.searchExact(query, k, double factor) → List<SearchHit>
idx.batchSearch(List<IVector<T>> queries, int k) → List<List<SearchHit>>
idx.rangeSearch(IVector<T> query, double radius) → List<SearchHit>

// --- Access ---
idx.getVector(String id) → IVector<T>
idx.close()  // AutoCloseable — release native resources if HPC

// --- SearchHit ---
hit.getIndex()  → int         // position in original data
hit.getId()     → String      // string ID
hit.getScore()  → T           // distance/similarity score
hit.getVector() → IVector<T>  // the vector itself
```

## IMutableVecIdx<T> extends IVecIdx<T>

```java
idx.isConcurrent() → boolean
idx.add(String id, IVector<T> vector) → boolean
idx.addAll(Map<String, IVector<T>> vectors) → int
idx.remove(String id) → boolean
idx.contains(String id) → boolean
idx.clear() → void
```
